// // import 'dart:math';
// //
// // import 'package:flutter/material.dart';
// //
// // void main() {
// //   runApp(MaterialApp(
// //     home: pruthvi(),
// //     debugShowCheckedModeBanner: false,
// //     title: 'pruthvi',
// //   ));
// // }
// //
// // class pruthvi extends StatefulWidget {
// //   const pruthvi({super.key});
// //
// //   @override
// //   State<pruthvi> createState() => _pruthviState();
// // }
// //
// // class _pruthviState extends State<pruthvi> {
// //   @override
// //   Widget build(BuildContext context) {
// //     Size size = MediaQuery.of(context).size;
// //
// //     /// height-200 [Text of SizeBox ni height 100 & ElevatedButton of SizeBox ni height 100] :--
// //     double height = MediaQuery.of(context).size.height - 200;
// //     double width = MediaQuery.of(context).size.width;
// //
// //     // print('height = $height');
// //     // print('width = $width');
// //
// //     /// minSize ae height and width bev mathi je minimum hoy ae apshe....
// //     double minSize = min(width, height);
// //
// //     return Scaffold(
// //       backgroundColor: Colors.blue,
// //       body: Center(
// //         child: Column(
// //           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
// //           children: [
// //             /// Timer Button :---
// //             SizedBox(
// //               height: 100,
// //               child: Center(
// //                 child: Text(
// //                   // 'player',
// //                   // display.isNotEmpty ? display : 'Player :$player',
// //                   '00:00',
// //                   style: TextStyle(
// //                     color: Colors.white,
// //                     fontSize: 25,
// //                     fontWeight: FontWeight.bold,
// //                   ),
// //                 ),
// //               ),
// //             ),
// //
// //             /// Play Board Button :---
// //             Center(
// //               child: Container(
// //                 // height: 300,
// //                 /// total width is 500 and height is same as width
// //                 /// total width = height is 500 - 60 [padding]
// //                 /// 500 - 60 = 440
// //                 // height: minSize * 440 / 500,
// //                 height: minSize * 44 / 50,
// //                 // width: 300,
// //                 /// total width is 500 - 60 [padding]
// //                 /// 500 - 60 = 440
// //                 // width: minSize * 440 / 500,
// //                 width: minSize * 44 / 50,
// //
// //                 decoration: BoxDecoration(
// //                     border: Border.all(
// //                   width: 2,
// //                   color: Colors.white,
// //                 )),
// //
// //                 /// padding is 60 => [right side 30 and left side 30 = total padding = 60(30 + 30)]
// //                 padding: EdgeInsets.all(
// //                   // 30,
// //                   // minSize * 30/500,
// //                   minSize * 3 / 50,
// //                 ),
// //                 child: Expanded(
// //                   /// builder lavva mate je Gridview ma je InkWell button htu ne aene cut krine GridView ni pchi [.builder] karyu and itemBuilder pchi [ctrl+space] karvu atle [(context, index) => ] aavi jashe => pachi ae InkWell ne paste kri devu.....
// //                   child: GridView.builder(
// //                     gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
// //                       crossAxisCount: 3,
// //                       mainAxisSpacing: 10,
// //                       crossAxisSpacing: 10,
// //                     ),
// //                     itemBuilder: (context, index) => InkWell(
// //                       onTap: () => ontap(index),
// //                       child: DecoratedBox(
// //                         decoration: BoxDecoration(
// //                           border: Border.all(
// //                             color: Colors.white,
// //                             width: 2,
// //                           ),
// //                         ),
// //                         child: Center(
// //                           child: Text(
// //                             // 'O',
// //                             playBoard[index],
// //                             ///////////////////////////////////////
// //                             style: TextStyle(
// //                               color: Colors.white,
// //                               fontWeight: FontWeight.bold,
// //                               fontSize: 35,
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //               ),
// //             ),
// //
// //             /// Reset Button :---
// //             SizedBox(
// //               height: 100,
// //               child: Center(
// //                 child: ElevatedButton(
// //                   // onPressed: () => print('hjdbh'),
// //                   onPressed: () => resetGame(),
// //                   child: Text(
// //                     'Reset game',
// //                     style: TextStyle(
// //                       fontWeight: FontWeight.bold,
// //
// //                       color: Colors.black,
// //                     ),
// //                   ),
// //                 ),
// //               ),
// //             )
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// //
// //   String display = '';
// //   String player = 'X';
// //   List playBoard = List.filled(9, '');
// //
// //   void ontap(int index) {
// //     if (playBoard[index] == '' && display == '') {
// //       setState(() {
// //         playBoard[index] = player;
// //         player = player == 'X' ? 'O' : 'X';
// //       });
// //       result();
// //     }
// //   }
// //
// //   void result() {
// //     List winnerPlayer = [
// //       [0, 1, 2],
// //       [3, 4, 5],
// //       [6, 7, 8],
// //       [0, 3, 6],
// //       [1, 4, 7],
// //       [2, 5, 8],
// //       [0, 4, 8],
// //       [2, 4, 6],
// //     ];
// //
// //     for (var board in winnerPlayer) {
// //       String first = playBoard[board[0]];
// //       String second = playBoard[board[1]];
// //       String third = playBoard[board[2]];
// //
// //       if (first == second && second == third && first != '') {
// //         setState(() {
// //           display = first;
// //           showDialog(
// //             context: context,
// //             builder: (context) => AlertDialog(
// //               title: Text('Win'),
// //               actions: [
// //                 Center(
// //                   child: ElevatedButton(
// //                     // onPressed: () => print('hjdbh'),
// //                     onPressed: () => resetGame(context),
// //                     child: Text(
// //                       'Reset game',
// //                       style: TextStyle(
// //                         fontWeight: FontWeight.bold,
// //                         color: Colors.black,
// //                       ),
// //                     ),
// //                   ),
// //                 )
// //               ],
// //             ),
// //           );
// //         });
// //         return;
// //       }
// //     }
// //   }
// //
// //   void resetGame([BuildContext? context]) {
// //     setState(() {
// //       player = 'X';
// //       display = '';
// //       playBoard = List.filled(9, '');
// //       if (context != null) {
// //         Navigator.pop(context);
// //       }
// //     });
// //   }
// // }
//
//
//
// import 'dart:math';
// import 'package:flutter/material.dart';
//
// void main() {
//   runApp(MaterialApp(
//     home: Pruthvi(),
//     debugShowCheckedModeBanner: false,
//     title: 'Pruthvi',
//   ));
// }
//
// class Pruthvi extends StatefulWidget {
//   const Pruthvi({super.key});
//
//   @override
//   State<Pruthvi> createState() => _PruthviState();
// }
//
// class _PruthviState extends State<Pruthvi> {
//   String display = '';
//   String player = 'X';
//   List<String> playBoard = List.filled(9, '');
//   bool isSinglePlayer = false;
//
//   @override
//   Widget build(BuildContext context) {
//     Size size = MediaQuery.of(context).size;
//
//     double height = MediaQuery.of(context).size.height - 200;
//     double width = MediaQuery.of(context).size.width;
//     double minSize = min(width, height);
//
//     return Scaffold(
//       backgroundColor: Colors.blue,
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             /// Mode Selection Buttons
//             Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 ElevatedButton(
//                   onPressed: () => setState(() {
//                     isSinglePlayer = true;
//                     //  resetGame();
//                   }),
//                   child: Text(
//                     'Single Player',
//                     style: TextStyle(
//                       fontWeight: FontWeight.bold,
//                       color: Colors.black,
//                     ),
//                   ),
//                 ),
//                 SizedBox(width: 20),
//                 ElevatedButton(
//                   onPressed: () => setState(() {
//                     isSinglePlayer = false;
//                     //  resetGame();
//                   }),
//                   child: Text(
//                     'Two Player',
//                     style: TextStyle(
//                       fontWeight: FontWeight.bold,
//                       color: Colors.black,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//
//             /// Timer Button
//             SizedBox(
//               height: 100,
//               child: Center(
//                 child: Text(
//                   '00:00',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 25,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ),
//             ),
//
//             /// Play Board Button
//             Center(
//               child: Container(
//                 height: minSize * 44 / 50,
//                 width: minSize * 44 / 50,
//                 decoration: BoxDecoration(
//                   border: Border.all(
//                     width: 2,
//                     color: Colors.white,
//                   ),
//                 ),
//                 padding: EdgeInsets.all(minSize * 3 / 50),
//                 child: GridView.builder(
//                   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                     crossAxisCount: 3,
//                     mainAxisSpacing: 10,
//                     crossAxisSpacing: 10,
//                   ),
//                   itemBuilder: (context, index) => InkWell(
//                     onTap: () => ontap(index),
//                     child: DecoratedBox(
//                       decoration: BoxDecoration(
//                         border: Border.all(
//                           color: Colors.white,
//                           width: 2,
//                         ),
//                       ),
//                       child: Center(
//                         child: Text(
//                           playBoard[index],
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontWeight: FontWeight.bold,
//                             fontSize: 35,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//
//             /// Reset Button
//             SizedBox(
//               height: 100,
//               child: Center(
//                 child: ElevatedButton(
//                   onPressed: () => resetGame(),
//                   child: Text(
//                     'Reset game',
//                     style: TextStyle(
//                       fontWeight: FontWeight.bold,
//                       color: Colors.black,
//                     ),
//                   ),
//                 ),
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
//
//   void ontap(int index) {
//     if (playBoard[index] == '' && display == '') {
//       setState(() {
//         playBoard[index] = player;//when i click on button some index like[1] is there and when i my player is o or x it will set instead of  that index
//         //  player = player == 'X' ? 'O' : 'X';//player change karvamate ternary op
//
//         if (player == 'X') {
//           player = 'O';
//         } else {
//           player = 'X';
//         }
//
//       });
//       result();
//       if (isSinglePlayer && player == 'O') {
//         //Future.delayed(Duration(milliseconds: 500), () => computerMove());
//         computerMove();
//       }
//     }
//   }
//
//   void computerMove() {
//     List<int> emptyIndices = [];
//     for (int i = 0; i < playBoard.length; i++) {
//       if (playBoard[i] == '') {
//         emptyIndices.add(i);
//       }
//     }
//     if (emptyIndices.isNotEmpty) {
//       int index = emptyIndices[Random().nextInt(emptyIndices.length)];
//       ontap(index);
//     }
//   }
//
//   void result() {
//     List<List<int>> winnerPlayer = [
//       [0, 1, 2],
//       [3, 4, 5],
//       [6, 7, 8],
//       [0, 3, 6],
//       [1, 4, 7],
//       [2, 5, 8],
//       [0, 4, 8],
//       [2, 4, 6],
//     ];
//
//     for (var board in winnerPlayer) {
//       String first = playBoard[board[0]];
//       String second = playBoard[board[1]];
//       String third = playBoard[board[2]];
//
//       if (first == second && second == third && first != '') {
//         setState(() {
//           display = first;
//           showDialog(
//             context: context,
//             builder: (context) => AlertDialog(
//               title: Text('Win'),
//               actions: [
//                 Center(
//                   child: ElevatedButton(
//                     onPressed: () => resetGame(context),
//                     child: Text(
//                       'Reset game',
//                       style: TextStyle(
//                         fontWeight: FontWeight.bold,
//                         color: Colors.black,
//                       ),
//                     ),
//                   ),
//                 )
//               ],
//             ),
//           );
//         });
//         return;
//       }
//     }
//   }
//
//   void resetGame([BuildContext? context]) {//optional parameters is imp for reset game ow it's not able to refresh properly........
//     setState(() {
//       player = 'X';
//       display = '';
//       playBoard = List.filled(9, '');//imp for display blank
//       if (context != null) {
//         Navigator.pop(context);//remove rout from stack...........
//       }
//     });
//   }
// }
//
