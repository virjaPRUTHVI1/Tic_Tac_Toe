// import 'dart:math';
// import 'package:flutter/material.dart';
//
// void main() {
//   runApp(MaterialApp(
//     home: Pruthvi(),
//     debugShowCheckedModeBanner: false,
//     title: 'Pruthvi',
//   ));
// }
//
// class Pruthvi extends StatefulWidget {
//   const Pruthvi({super.key});
//
//   @override
//   State<Pruthvi> createState() => _PruthviState();
// }
//
// class _PruthviState extends State<Pruthvi> {
//   String display = '';
//   String player = 'X';
//   List<String> playBoard = List.filled(9, '');
//
//   @override
//   Widget build(BuildContext context) {
//     Size size = MediaQuery.of(context).size;
//
//     double height = MediaQuery.of(context).size.height - 200;
//     double width = MediaQuery.of(context).size.width;
//     double minSize = min(width, height);
//
//     print('minsize:  ,$minSize');
//     print('height:  ,$height');
//     print('width:  ,$width');
//     print('size:  ,$size');
//     return Scaffold(
//       backgroundColor: Colors.blue,
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 ElevatedButton(
//                   onPressed: () {},
//                   child: Text(
//                     'one player',
//                     style: TextStyle(
//                         fontWeight: FontWeight.bold, color: Colors.black),
//                   ),
//                 ),
//                 SizedBox(
//                   width: 50,
//                 ),
//                 ElevatedButton(
//                   onPressed: () => ontap,
//                   child: Text(
//                     'two player',
//                     style: TextStyle(
//                         fontWeight: FontWeight.bold, color: Colors.black),
//                   ),
//                 )
//               ],
//             ),
//
//             SizedBox(
//               height: 50,
//               child: Center(
//                 child: Text(
//                   '00:00',
//                   style: TextStyle(
//                     color: Colors.black,
//                     fontSize: 25,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ),
//             ),
//
//             /// Play Board Button
//             Center(
//               child: Container(
//                 height: minSize * 44 / 50,
//                 // height: 200,
//                 width: minSize * 44 / 50,
//                 // width: 200,
//                 decoration: BoxDecoration(
//                   border: Border.all(
//                     width: 2,
//                     color: Colors.white,
//                   ),
//                 ),
//                 padding: EdgeInsets.all(minSize * 3 / 50),
//                 child: Expanded(
//                   child: GridView.builder(//use this cause screen pur ui dekhai aetlu j load karshe ane scroll kariye tyare scroll karelu............
//                     itemCount: 9,
//                     gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                       crossAxisCount: 3,
//                       mainAxisSpacing: 10,
//                       crossAxisSpacing: 10,
//                     ),
//                     itemBuilder: (context, index) => InkWell(
//                       onTap: () => ontap(index),
//                       child: DecoratedBox(
//                         decoration: BoxDecoration(
//                           border: Border.all(
//                             color: Colors.white,
//                             width: 2,
//                           ),
//                         ),
//                         child: Center(
//                           child: Text(
//                             playBoard[index],
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontWeight: FontWeight.bold,
//                               fontSize: 35,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//
//             /// Reset Button
//             SizedBox(
//               height: 50,
//               child: Center(
//                 child: ElevatedButton(
//                   onPressed: () => resetGame(),
//                   child: Text(
//                     'Reset game',
//                     style: TextStyle(
//                       fontWeight: FontWeight.bold,
//                       color: Colors.black,
//                     ),
//                   ),
//                 ),
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
//
//   void ontap(int index) {
//     if (playBoard[index] == '' && display == '') {
//       setState(() {
//         playBoard[index] =
//             player; //when i click on button some index like[1] is there and when i my player is o or x it will set instead of  that index
//         //  player = player == 'X' ? 'O' : 'X';//player change karvamate ternary op
//
//         if (player == 'X') {
//           player = 'O';
//         } else {
//           player = 'X';
//         }
//       });
//       result();
//
//     }
//   }
//
//   void result() {
//     List  winnerPlayer = [
//       [0, 1, 2],
//       [3, 4, 5],
//       [6, 7, 8],
//       [0, 3, 6],
//       [1, 4, 7],
//       [2, 5, 8],
//       [0, 4, 8],
//       [2, 4, 6],
//     ];
//
//     for (var board in winnerPlayer) {//loop will continue till winnwr will find or all possibility space filled..............
//       String first = playBoard[board[0]];//require to conver int to string
//       String second = playBoard[board[1]];
//       String third = playBoard[board[2]];//why?
//
//       if (first == second &&
//           second == third &&
//           first!= '') { //aa winnerplayer vali index considerd karshe.....
//         setState(() {
//           display = first; //if first iss 0 than 0 or x than display x.............
//           showDialog(
//             context: context,
//             builder: (context) => AlertDialog(
//               title: Text('winner is $first'),
//               actions: [
//                 Center(
//                   child: ElevatedButton(
//                     onPressed: () => resetGame(context),
//                     child: Text(
//                       'Reset game',
//                       style: TextStyle(
//                         fontWeight: FontWeight.bold,
//                         color: Colors.black,
//                       ),
//                     ),
//                   ),
//                 )
//               ],
//             ),
//           );
//         });
//         return; //stop excecution of process after dialogbox nd win desided........
//       }
//     }
//   }
//
//   void resetGame([BuildContext? context]) {
//     //optional parameters is imp for reset game ow it's not able to refresh properly........
//     setState(() {
//       player = 'X';
//       display = '';
//       playBoard = List.filled(9, ''); //imp for display blank
//       if (context != null) {
//         Navigator.pop(context); //dialog box band karva je open thai che jyare reset par click karvama aave...........
//       }
//     });
//   }
// }

// import 'dart:math';
// import 'package:flutter/material.dart';
//
// void main() {
//   runApp(MaterialApp(
//     home: Pruthvi(),
//     debugShowCheckedModeBanner: false,
//     title: 'Pruthvi',
//   ));
// }
//
// class Pruthvi extends StatefulWidget {
//   const Pruthvi({super.key});
//
//   @override
//   State<Pruthvi> createState() => _PruthviState();
// }

import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Pruthvi(),
    debugShowCheckedModeBanner: false,
    title: 'Pruthvi',
  ));
}

class Pruthvi extends StatefulWidget {
  const Pruthvi({super.key});

  @override
  State<Pruthvi> createState() => _PruthviState();
}

class _PruthviState extends State<Pruthvi> {
  String display = '';
  String player = 'X';
  List<String> playBoard = List.filled(9, '');
  bool SinglePlayer = false;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    double height = MediaQuery.of(context).size.height - 200;
    double width = MediaQuery.of(context).size.width;
    double minSize = min(width, height);

    return Scaffold(
      backgroundColor: Colors.blue,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () => setState(() {
                    SinglePlayer = true;
                  }),
                  child: Text(
                    'Single Player',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ),
                SizedBox(width: 20),
                ElevatedButton(
                  onPressed: () => setState(() {
                    SinglePlayer = false;
                  }),
                  child: Text(
                    'Two Player',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 100,
              child: Center(
                child: Text(
                  '00:00',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            Center(
              child: Container(
                height: minSize * 44 / 50,
                width: minSize * 44 / 50,
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 2,
                    color: Colors.white,
                  ),
                ),
                padding: EdgeInsets.all(minSize * 3 / 50),
                child: GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                  ),
                  itemBuilder: (context, index) => InkWell(
                    onTap: () => ontap(index),
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.white,
                          width: 2,
                        ),
                      ),
                      child: Center(
                        child: Text(
                          playBoard[index],
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 35,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 100,
              child: Center(
                child: ElevatedButton(
                  onPressed: () => reset(),
                  child: Text(
                    'Reset game',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  void ontap(int index) {
    if (playBoard[index] == '' && display == '') {
      setState(() {
        playBoard[index] =
            player; //when i click on button some index like[1] is there and when i my player is o or x it will set instead of  that index
        //  player = player == 'X' ? 'O' : 'X';//player change karvamate ternary op

        if (player == 'X') {
          player = 'O';
        } else {
          player = 'X';
        }
      });
      result(); //above condtition should always fill if game is one or two players
      if (SinglePlayer && player == 'O') {
        automatic();
      }
    }
  }

  void automatic() {
    List<int> emptyspace = [];
    print('virja======$emptyspace');//fins blank space to enter computer's turn......
    for (int i = 0; i < 9; i++) {
      if (playBoard[i] == '') {

        emptyspace.add(i);
        print('**************************************emptys , $emptyspace');//empty space ne list ma add karva...
      }
    }
    if (emptyspace.isNotEmpty) {//empty space is nor empty(means list ni andar empty space mate ni index hovi joiye...)
      int index = emptyspace[Random().nextInt(emptyspace.length)];//random index mate.....
      ontap(index);
    }

  }

  void result() {
    List winnerPlayer = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];

    for (var board in winnerPlayer) {
      String first = playBoard[board[0]];
      String second = playBoard[board[1]];
      String third = playBoard[board[2]];

      if (first == second && second == third && first != '') {
        setState(() {
          display = first;
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Winner is $first'),
              actions: [
                Center(
                  child: ElevatedButton(
                    onPressed: () => reset(context),
                    child: Text(
                      'Reset',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                )
              ],
            ),
          );
        });
      }
    }
  }

  void reset([BuildContext? context]) {
    //optional parameters is imp for reset game ow it's not able to refresh properly........
    setState(() {
      player = 'X';
      display = '';
      playBoard = List.filled(9, ''); //imp for display blank
      if (context != null) {
        Navigator.pop(
            context); //remove rout from stack.means dialogbox..........
      }
    });
  }
}
